#include<stdio.h>
void display(int array[],int n)
{
    int i;
    printf("[");
    for(i=0;i<n;i++)
    {
        printf("%d->",array[i]);
    }
    printf("]");
}
void Insertion_sort(int array[],int n)
{
    int i,value,hole;
    for(i=1;i<n;i++)
    {
        value=array[i];
        hole=i;
        while(hole>0 && array[hole-1]>value)
        {
            array[hole]=array[hole-1];
            hole--;
        }
        array[hole]=value;
    }
}
void main()
{
    int n,i;
    printf("Please entr ? many ele u wnt to insert:-");
    scanf("%d",&n);
    int array[n];
    printf("Please entr array ele:-\n");
    for(i=0;i<n;i++)
    {
        scanf("%d",&array[i]);
    }
    printf("Unsorted Array:-\n");
    display(array,n);
    Insertion_sort(array,n);
    printf("\nSorted Array:-\n");
    display(array,n);
}