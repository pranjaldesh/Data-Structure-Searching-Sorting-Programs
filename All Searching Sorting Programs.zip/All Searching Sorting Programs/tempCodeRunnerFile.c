#include<stdio.h>
void display(int array[],int n)
{
    int i;
    printf("[");
    for(i=0;i<n;i++)
    {
        printf("%d->",array[i]);
    }
    printf("]");
}
void Insertion_sort(int array[],int n)
{
    int i,value,hole;
    for(i=1;i<n;i++)
    {
        value=array[i];
        hole=i;