#include<stdio.h>
#include<stdlib.h>
struct node
{
int data;
struct node* next;
};
struct node* createnode()
{
    struct node* nn=NULL;
    nn=(struct node*)malloc(sizeof(struct node));
    if(nn==NULL)
    {
        printf("Linked list not exist\n");
        return NULL;
    }
    else
    {
        int x;
        printf("Please enter a data:-");
        scanf("%d",&x);
        nn->data=x;
        nn->next=NULL;
        return nn;
    }
}
void createlinkedlist(struct node** head)
{
    struct node* tempnode=*head;
    struct node* nn=NULL;
    nn=createnode();
    if(*head==NULL)
    {
        *head=nn;
    }
    else
    {
        while(tempnode->next!=NULL)
        {
            tempnode=tempnode->next;
        }
        tempnode->next=nn;
    }
}
void displaylinkedlist(struct node* head)
{
    if(head==NULL)
    {
        printf("Linked list not exist\n");
    }
    else
    {
        while(head!=NULL)
        {
            printf("%d->",head->data);
            head=head->next;
        }
    }
}
void insertatfirst(struct node** head)
{
    struct node* nn=NULL;
    nn=createnode();
    (nn->next)=*head;
    *head=nn;
}
void insertatlast(struct node** head)
{
    createlinkedlist(head);
}
int countnode(struct node* head)
{
    int count;
    while(head!=NULL)
    {
        count++;
        head=head->next;
    }
    return count;
}
void insertatposition(struct node** head)
{
    int position,i;
    struct node* nn=NULL;
    printf("Please enter position:-");
    scanf("%d",&position);
    int no_of_nodes=countnode(*head);
    if(position==1)
    {
        insertatfirst(head);
    }
    else if(position==(no_of_nodes+1))
    {
        insertatlast(head);
    }
    else if(position<1 || position>(no_of_nodes+1))
    {
        printf("Invalid Choice\n");
    }
    else
    {
        nn=createnode();
        struct node* tempnode=*head;
        for(i=1;i<(position-1);i++)
        {
            tempnode=tempnode->next;
        }
        nn->next=tempnode->next;
        tempnode->next=nn;
    }
}
void deleteatfirst(struct node** head)
{
    if((*head)==NULL)
    {
        printf("Linked list not exist\n");
    }
    else
    {
        struct node* tempnode=*head;
        *head=(*head)->next;
        free(tempnode);
    }
}
void deleteatlast(struct node** head)
{
    if(*head==NULL)
    {
        printf("Linked list not exist\n");
    }
    else if((*head)->next==NULL)
    {
        free(*head);
        *head=NULL;
    }
    else if((*head)->next->next==NULL)
    {
        free((*head)->next);
        (*head)->next=NULL;
    }
    else
    {
        struct node* tempnode1=*head;
        struct node* tempnode2=*head;
        while(tempnode1->next!=NULL)
        {
            tempnode2=tempnode2->next;
            tempnode1=tempnode2->next;
        }
        free(tempnode1);
        tempnode2->next=NULL;
    }
}
void main()
{
    struct node* first=NULL;
    int choice;
    do
    {
        printf("\n1.Createlinkedlist\n");
        printf("2.Displaylinkedlist\n");
        printf("3.Insertatfirst\n");
        printf("4.Insertatlast\n");
        printf("5.Insertatposition\n");
        printf("6.Deleteatfirst\n");
        printf("7.Deleteatlast\n");
        printf("Please enter ur choice:-");
        scanf("%d",&choice);
        switch(choice)
        {
            case 1:
            createlinkedlist(&first);
            break;
            case 2:
            displaylinkedlist(first);
            break;
            case 3:
            insertatfirst(&first);
            break;
            case 4:
            insertatlast(&first);
            break;
            case 5:
            insertatposition(&first);
            break;
            case 6:
            deleteatfirst(&first);
            break;
            case 7:
            deleteatlast(&first);
            break;
        }
    } while(choice!=8);
}