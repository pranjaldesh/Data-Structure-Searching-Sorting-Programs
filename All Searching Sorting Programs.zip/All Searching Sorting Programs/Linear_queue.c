#include<stdio.h>
#define MAX 7
struct queue
{
int array[MAX];
int front;
int rear;
};
int ISFULL(struct queue* ptr)
{
    if(ptr->rear==MAX-1)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}
int ISEMPTY(struct queue* ptr)
{
    if(ptr->front==ptr->rear)
    {
        ptr->front=ptr->rear=-1;
        return 1;
    }
    else
    {
        return 0;
    }
}
void insert(struct queue* ptr,int value)
{
    ptr->rear++;
    ptr->array[ptr->rear]=value;
}
void delete(struct queue* ptr)
{
    (ptr->front)++;
    printf("Deleted Element:-%d",ptr->array[ptr->front]);
}
void Display(struct queue* ptr)
{
    int i;
    for(i=(ptr->front)+1;i<=ptr->rear;i++)
    {
        printf("%d->",ptr->array[i]);
    }
    printf("\n");
}
int main()
{
struct queue obj;
obj.rear=obj.front=-1;
int value,choice;
do
{
    printf("\nPlease entr ur choice:-\n");
    printf("1.Insert:-\n");
    printf("2.Delete:-\n");
    printf("3.Display:-\n");
    printf("4.ISFULL:-\n");
    printf("5.ISEMPTY:-\n");
    scanf("%d",&choice);
    switch(choice)
    {
        case 1:
        if(ISFULL(&obj))
        {
            printf("Queue is Full\n");
        }
        else
        {
            printf("Enter value:-");
            scanf("%d",&value);
            insert(&obj,value);
        }
        break;
        case 2:
        if(ISEMPTY(&obj))
        {
            printf("Queue is empty\n");
        }
        else
        {
            delete(&obj);
        }
        break;
        case 3:Display(&obj);
        break;
        case 4:
        if(ISFULL(&obj))
        {
            printf("Queue is full\n");
        }
        else
        {
           printf("Queue has some space\n"); 
        }
        break;
        case 5:
        if(ISEMPTY(&obj))
        {
            printf("Queue is empty\n");
        }
        else
        {
           printf("Queue is not empty\n"); 
        }
        break;
        default:printf("Invalid choice\n");
    }
} while(choice!=0);

}