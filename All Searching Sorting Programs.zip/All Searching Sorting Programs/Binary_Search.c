#include<stdio.h>
void selection_sort(int array[],int n)
{
    int i,j,temp;
    for(i=0;i<n-1;i++)
    {
        for(j=i+1;j<n;j++)
        {
            if(array[i]>array[j])
            {
                temp=array[i];
                array[i]=array[j];
                array[j]=temp;
            }
        }
    }
}
int Binary_Search(int array[],int n,int search)
{
    int first=0;
    int last=n-1;
    int mid;
    while(first<=last)
    {
    mid=(first+last)/2;
    if(array[mid]==search)
    {
        return mid;
    }
    else if(search<array[mid])
    {
        last=mid-1;
    }
    else
    {
        first=mid+1;
    }
    }
    return -1;
} 
void display(int array[],int n)
{
    int i;
    printf("[");
    for(i=0;i<n;i++)
    {
        printf("%d->",array[i]);
    }
    printf("]");
}
void main()
{
    int i,n,search;
    printf("Please entr no. of ele-:");
    scanf("%d",&n);
    int array[n];
    printf("Please enter array elements:-\n");
    for(i=0;i<n;i++)
    {
        scanf("%d",&array[i]);
    }
    printf("Unsorted Array:-\n");
    display(array,n);
    selection_sort(array,n);
    printf("Sorted Array:-\n");
    display(array,n);
    printf("Please entr ele u wnt to search:-");
    scanf("%d",&search);
    int index=Binary_Search(array,n,search);
    if(index==-1)
    {
        printf("Element not found\n");
    }
    else
    {
        printf("Element found at %dth location\n",index);
    }
}