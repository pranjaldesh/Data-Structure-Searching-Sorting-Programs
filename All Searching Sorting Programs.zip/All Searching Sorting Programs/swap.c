#include<stdio.h>
void swap(int* p1,int* p2)
{
    int* temp;
    temp=p1;
    p1=p2;
    p2=temp;

    printf("a=%d\n",(*p1));
    printf("b=%d\n",(*p2));
}
void main()
{
    int a,b;
    printf("Enter 1st no:-");
    scanf("%d",&a);
    printf("Enter 2nd no:-");
    scanf("%d",&b);
    swap(&a,&b);
}