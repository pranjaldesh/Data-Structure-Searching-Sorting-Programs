#include<stdio.h>
#include<stdlib.h>
struct node
{
    struct node* prev;
    int data;
    struct node* next;
};
struct node* createnode()
{
    struct node* nn=NULL;
    nn=(struct node*)malloc(sizeof(struct node));
    if(nn==NULL)
    {
        printf("Memory not allocated\n");
        return NULL;
    }
    else
    {
        int x;
        printf("Please enter a data:-");
        scanf("%d",&x);
        nn->data=x;
        nn->prev=NULL;
        nn->next=NULL;
        return nn;
    }
}
void createlinkedlist(struct node** h_first,struct node** h_last)
{
    struct node* nn=NULL; 
    nn=createnode();
    if(*h_first==NULL)
    {
        *h_first=nn;
        *h_last=nn;
    }
    else
    {
        nn->prev=*h_last;
        (*h_last)->next=nn;
        *h_last=nn;
    }
}
void insertatfirst(struct node** h_first,struct node** h_last)
{
    struct node* nn=NULL;
    nn=createnode();
    if(*h_first==NULL)
    {
        *h_first=*h_last=nn;
    }
    else
    {
        nn->next=*h_first;
        (*h_first)->prev=nn;
        (*h_first)=nn;
    }
}
void insertatlast(struct node** h_first,struct node** h_last)
{
    createlinkedlist(h_first,h_last);
}
int countnodes(struct node* h_first)
{
    int count=0;
    while(h_first!=NULL)
    {
        count++;
        h_first=h_first->next;
    }
    return count;
}
void insertatposition(struct node** h_first,struct node** h_last)
{
    struct node* nn=NULL;
    struct node* tempnode=*h_first;
    int position,no_of_nodes;
    no_of_nodes=countnodes(*h_first);
    printf("Please enter a position:-");
    scanf("%d",&position);
    if(position==1)
    {
        insertatfirst(h_first,h_last);
    }
    else if(position==(no_of_nodes+1))
    {
        insertatlast(h_first,h_last);
    }
    else if(position<1 || position>(no_of_nodes+1))
    {
        printf("Invalid Position\n");
        insertatposition(h_first,h_last);
    }
    else
    {
        nn=createnode();
        int i=1;
        while(i<position-1)
        {
            tempnode=tempnode->next;
            i++;
        }
        nn->prev=tempnode;
        nn->next=tempnode->next;
        (tempnode->next)->prev=nn;
        tempnode->next=nn;
    }
}
void deleteatfirst(struct node** h_first,struct node** h_last)
{
    if(*h_first==NULL)
    {
        printf("Linked list not exist\n");
    }
    else if((*h_first)->next==NULL)
    {
        struct node* tempnode=*h_first;
        *h_first=NULL;
        *h_last=NULL;
        free(tempnode);  
    }
    else
    {
        struct node* tempnode=*h_first;
        *h_first=(*h_first)->next;
        (*h_first)->prev=NULL;
        free(tempnode);
    }
}
void deleteatlast(struct node** h_first,struct node** h_last)
{
    if(*h_first==NULL)
    {
        printf("Linked list not exist\n");
    }
    else if((*h_first)->next==NULL)
    {
        struct node* tempnode=*h_first;
        *h_first=NULL;
        *h_last=NULL;
        free(tempnode);
    }
    else
    {
        struct node* tempnode=*h_last;
        *h_last=(*h_last)->prev;
        (*h_last)->next=NULL;
        free(tempnode);
    }
}
void deleteatposition(struct node** h_first,struct node** h_last)
{
    int position,no_of_nodes;
    struct node* tempnode=*h_first;
    no_of_nodes=countnodes(*h_first);
    printf("Please enter a position:-");
    scanf("%d",&position);
    if(position==1)
    {
        deleteatfirst(h_first,h_last);
    }
    else if(position==no_of_nodes)
    {
        deleteatlast(h_first,h_last);
    }
    else if(position<1 || position>(no_of_nodes))
    {
        printf("Invalid Position\n");
        deleteatposition(h_first,h_last);
    }
    else
    {
        int i=1;
        while(i<position)  
        {
            tempnode=tempnode->next;
            i++;
        }
        (tempnode->prev)->next=tempnode->next;
        (tempnode->next)->prev=tempnode->prev;
        free(tempnode);
    }
}
void display(struct node* h_first)
{
    if(h_first==NULL)
    {
        printf("Linked list not exist\n");
    }
    else
    {
        while(h_first!=NULL)
        {
            printf("%d->",h_first->data);
            h_first=h_first->next;
        }
    }
}
void main()
{
    int choice;
    struct node* first=NULL;
    struct node* last=NULL;
    do
    {
     printf("\n1.Create linkedlist\n");
     printf("2.Insert at First\n");
     printf("3.Insert at last\n");
     printf("4.Insert at position\n");
     printf("5.Delete at first\n");
     printf("6.Delete at last\n");
     printf("7.Delete at position\n");
     printf("8.Display\n");
     printf("9.exit\n");
     printf("Please enter your choice\n");
     scanf("%d",&choice);
     switch(choice)
     {
         case 1:createlinkedlist(&first,&last);
         break;
         case 2:insertatfirst(&first,&last);
         break;
         case 3:insertatlast(&first,&last);
         break;
         case 4:insertatposition(&first,&last);
         break;
         case 5:deleteatfirst(&first,&last);
         break;
         case 6:deleteatlast(&first,&last);
         break;
         case 7:deleteatposition(&first,&last);
         break;
         case 8:display(first);
         break;
     }  
    }while (choice!=9);
    printf("End!!");
}

