#include<stdio.h>
#include<stdlib.h>
struct node
{
int data;
struct node* next;
};
struct node* createnode()
{
    struct node* nn=NULL;
    nn=(struct node*)malloc(sizeof(struct node));
    if(nn==NULL)
    {
        printf("Linked list not exist\n");
        return NULL;
    }
    else
    {
        int x;
        printf("Please enter a data:-");
        scanf("%d",&x);
        nn->data=x;
        nn->next=NULL;
        return nn;
    }
}
void createlinkedlist(struct node** head)
{
        struct node* nn=NULL;
        nn=createnode();
        struct node* tempnode=*head;
        if(*head==NULL)
        {
            *head=nn;
            nn->next=nn;
        }   
        else
        {
            while(tempnode->next!=*head)
            {
                tempnode=tempnode->next;
            }
            tempnode->next=nn;
            nn->next=*head;
        }
}
void insertatfirst(struct node** head)
{
    struct node* nn=NULL;
    nn=createnode();
    struct node* tempnode=*head;
  
    if(*head==NULL)
    {
        *head=nn;
        nn->next=nn;
    }
    else
    {
        while(tempnode->next!=*head)
        {
            tempnode=tempnode->next;
        }
        nn->next=*head;
        tempnode->next=nn;
        *head=nn;
    }
}
void insertatlast(struct node** head)
{
    createlinkedlist(head);
}
int countnodes(struct node* head)
{
    int count=0;
    struct node* tempnode=head;
    do
    {
        count++;
        tempnode=tempnode->next;
    }while(tempnode!=head);
    return count;
}
void insertatposition(struct node** head)
{
    struct node* nn=NULL;
    struct node* tempnode=*head;
    int position,no_of_nodes,i;
    no_of_nodes=countnodes(*head);
    printf("Please enter a position:-\n");
    scanf("%d",&position);
    if(position==1)
    {
        insertatfirst(head);
    }
    else if(position==(no_of_nodes+1))
    {
        insertatlast(head);
    }
    else if(position<1 || position>(no_of_nodes))
    {
        printf("Invalid Position\n");
        insertatposition(head);
    }
    else
    {
        nn=createnode();
        for(i=0;i<(position-1);i++)
        {
            tempnode=tempnode->next;
        }
        nn->next=tempnode->next;
        tempnode->next=nn;
    }
}
void deleteatfirst(struct node** head)
{
    if(*head==NULL)
    {
        printf("Linkedlist not exist\n");
    }
    else if((*head)->next==*head)
    {
        free(*head);
        *head=NULL;
    }
    else
    {
        struct node* tempnode=*head;
        struct node* travnode=*head;
        while(tempnode->next!=*head)
        {
            tempnode=tempnode->next;
        }
        tempnode->next=(*head)->next;
        *head=(*head)->next;
        free(travnode);
    }
}
void deleteatlast(struct node** head)
{
    if(*head==NULL)
    {
        printf("Linkedlist not exist\n");
    }
    else if((*head)->next==*head)
    {
        free(*head);
        *head=NULL;
    }
    else
    {
        struct node* tempnode=*head;
        while(tempnode->next->next!=*head)
        {
            tempnode=tempnode->next;
        }
        free(tempnode->next);
        tempnode->next=*head;
    }
}
void deleteatposition(struct node** head)
{
    int position,no_of_nodes;
    struct node* tempnode=*head;
    struct node* nextnode=NULL;
    no_of_nodes=countnodes(*head);
    if(position==1)
    {
        deleteatfirst(head);
    }
    else if(position==(no_of_nodes))
    {
        deleteatlast(head);
    }
    else if(position<1 || position>no_of_nodes)
    {
        printf("Invalid Choice\n");
        deleteatposition(head);   
    }
    else
    {
        int i=1;
        while(i<position-1)
        {
            tempnode=tempnode->next;
        }
        nextnode=tempnode->next;
        tempnode->next=nextnode->next;
        free(nextnode);
    }
}
void displaylinkedlist(struct node* head)
{
    struct node* tempnode=head;
    if(head==NULL)
    {
        printf("Linked list not exist\n");
    }
    else
    {
        do
        {
            printf("%d->",tempnode->data);
            tempnode=tempnode->next;
        } while(tempnode!=head);
    }
}
void main()
{
    struct node* first=NULL;
    int choice;
    do
    {
        printf("\n1.Createlinkedlist\n");
        printf("2.Displaylinkedlist\n");
        printf("3.Insertatfirst\n");
        printf("4.Insertatlast\n");
        printf("5.Insertatposition\n");
        printf("6.Deleteatfirst\n");
        printf("7.Deleteatlast\n");
        printf("8.Deleteatposition\n");
        printf("Please enter ur choice:-");
        scanf("%d",&choice);
        switch(choice)
        {
            case 1:createlinkedlist(&first);
            break;
            case 2:displaylinkedlist(first);
            break;
            case 3:insertatfirst(&first);
            break;
            case 4:insertatlast(&first);
            break;
            case 5:insertatposition(&first);
            break;
            case 6:deleteatfirst(&first);
            break;
            case 7:deleteatlast(&first);
            break;
            case 8:deleteatposition(&first);
            break;
        }
    } while(choice!=9);
}