#include<stdio.h>
void display(int array[],int n)
{
    int i;
    printf("[");
    for(i=0;i<n;i++)
    {
        printf("%d->",array[i]);
    }
    printf("]\n");
}
void selection_sort(int array[],int n)
{
    int i,j,temp,flag=0;
    for(i=0;i<n-1;i++)
    {
        for(j=i+1;j<n;j++)
        {
            if(array[i]>array[j])
            {
                flag=1;
                temp=array[i];
                array[i]=array[j];
                array[j]=temp;
            }
        }
    }
    if(flag==0)
    {
        printf("===Array is already sorted===\n");
    }
}
void main()
{
    int n,i,flag;
    printf("Please enter the no.of ele u wnt to insert:-");
    scanf("%d",&n);
    int array[n];
    printf("Please enter the ele:-");
    for(i=0;i<n;i++)
    {
        scanf("%d",&array[i]);
    }
    printf("Unsorted array:-");
    display(array,n);
    selection_sort(array,n);
    printf("Sorted array:-");
    display(array,n);
    
}