#include<stdio.h>
void display(int array[],int n)
{
    int i;
    printf("[");
    for(i=0;i<n;i++)
    {
        printf("%d->",array[i]);
    }
    printf("]\n");
}
void merge(int array[],int low,int mid,int high)
{
    int barray[10],i,j,k=0;
    i=low;
    j=mid+1;
    while(i<=mid && j<=high)
    {
        if(array[i]<array[j])
        {
            barray[k]=array[i];
            i++;
            k++;
        }
        else
        {
            barray[k]=array[j];
            j++;
            k++;
        } 
    } 
        while(i<=mid)
        {
            barray[k]=array[i];
            k++;
            i++;
        }
        while(j<=high)
        {
            barray[k]=array[i];
            k++;
            j++;  
        }
        k=0;
        for(i=low;i<=high;i++)
        {
            array[i]=barray[k];
            k++;
        }
}
void Merge_Sort(int array[],int low,int high)
{
    int mid;
    if(low<high)
    {
        mid=(low+high)/2;
        Merge_Sort(array,low,mid);
        Merge_Sort(array,mid+1,high);
        merge(array,low,mid,high);
    }
}
void main()
{
    int n,i;
    printf("Please enter no.of ele:-");
    scanf("%d",&n);
    int array[n];
    printf("Please enter array ele:-\n");
    for(i=0;i<n;i++)
    {
        scanf("%d",&array[i]);
    }
    printf("Unsorted Array:-");
    display(array,n);
    Merge_Sort(array,0,n-1);
    printf("Sorted Array:-");
    display(array,n);
}