#include<stdio.h>
#define MAX 7
struct stack
{
    int top;
    int array[MAX];
};
int ISOVERFLOW(struct stack* ptr)
{
    if(ptr->top==MAX-1)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}
int ISUNDERFLOW(struct stack* ptr)
{
    if(ptr->top==-1)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}
void PUSH(struct stack* ptr,int value)
{
    ptr->top++;
    ptr->array[ptr->top]=value;
}
void POP(struct stack* ptr)
{
    printf("Popped element is:-%d",ptr->array[ptr->top]);
    ptr->top--;
}
void display(struct stack* ptr)
{
    int i;
    for(i=ptr->top;i>=0;i--)
    {
        printf("%d->",ptr->array[i]);
    }
}
void main()
{
    struct stack obj;
    obj.top=-1;
    int choice,value;
    do
    {
        printf("\n1.PUSH\n");
        printf("2.POP\n");
        printf("3.DISPLAY\n");
        printf("4.ISUNDERFLOW\n");
        printf("5.ISOVERFLOW\n");
        printf("Please enter ur choice:-\n");
        scanf("%d",&choice);
        switch(choice)
        {
            case 1:
            if(ISOVERFLOW(&obj))
            {
                printf("Stack is full\n");
            }
            else
            {
                printf("Please enter a value:-");
                scanf("%d",&value);
                PUSH(&obj,value);
            }
            break;
            case 2:
            if(ISUNDERFLOW(&obj))
            {
                printf("Stack is empty\n");
            }
            else
            {
                POP(&obj);
            }
            break;
            case 3:
            display(&obj);
            break;
            case 4:if(ISUNDERFLOW(&obj))
            {
                printf("Stack is empty\n");
            }          
            else
            {
                printf("%d positions are filled",obj.top+1);
            }
            break;
            case 5:if(ISOVERFLOW(&obj))
            {
                printf("Stack is full\n");
            }          
            else
            {
                printf("%d positions are vacant",MAX-(obj.top-1));
            }
            break;
            default:printf("Invalid choice\n");
        }
        
    } while(choice!=0);
    
}