#include<stdio.h>
int linear_search(int array[],int n,int search)
{
    int i;
    for(i=0;i<n;i++)
    {
        if(array[i]==search)
        {
            return i;
        }
    }
    return -1;
}
void display(int array[],int n)
{
    printf("[");
    for(int i=0;i<n;i++)
    {
        printf("%d->",array[i]);
    }
    printf("]\n");
}
void main()
{
    int n,i,search;
    printf("Please entr no. of ele:-");
    scanf("%d",&n);
    int array[n];
    printf("Please entr array ele:-");
    for(i=0;i<n;i++)
    {
        scanf("%d",&array[i]);
    }
    printf("Array:-");
    display(array,n);
    printf("Please enter the element u wnt to search:-");
    scanf("%d",&search);
    int index=linear_search(array,n,search);
    if(index==-1)
    {
        printf("Element not found\n");
    }
    else
    {
         printf("Element found at %dth index",index);
    }
    
}