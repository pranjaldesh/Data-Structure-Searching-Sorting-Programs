#include<stdio.h>
#define MAX 7
struct QUEUE
{
 int array[MAX];
 int front;
 int rear;
 int count;
};
int ISFULL(struct QUEUE* queue_ptr)
{
 if(queue_ptr->count==MAX)
 {
 return 1;
 }
 else
 {
 return 0;
 }
 
}
void INSERT(struct QUEUE* queue_ptr,int value)
{
 (queue_ptr->count)++;
 queue_ptr->rear=(queue_ptr->rear+1)%MAX;
 queue_ptr->array[queue_ptr->rear]=value;
}
int ISEMPTY(struct QUEUE* queue_ptr)
{
 if(queue_ptr->count==0)
 {
 return 1;
 }
 else
 {
 return 0;
 }
}
void DELETE(struct QUEUE* queue_ptr)
{
 (queue_ptr->count)--;
 queue_ptr->front=(queue_ptr->front+1)%MAX;
 printf("Deleted Element is=%d",queue_ptr->array[queue_ptr->front]);
}
void DISPLAY(struct QUEUE* queue_ptr)
{
int i;
i=(queue_ptr->front+1);
while(i!=queue_ptr->rear)
{
 printf("%d, ",queue_ptr->array[i]);
 i=(i+1)%MAX;
}
//printf("%d, ",queue_ptr->array[i]);
}
int main()
{
 struct QUEUE queue_obj;
 queue_obj.front=queue_obj.rear=-1;
 queue_obj.count=0;
 int value,choice;
 do
 {
 printf("\nPlz enter ur choice=\n");
 printf("1.INSERT\n");
 printf("2.DELETE\n");
 printf("3.DISPLAY\n");
 printf("4.ISFULL\n");
 printf("5.ISEMPTY\n");
 scanf("%d",&choice);
 switch(choice)
 {
 case 1: if(ISFULL(&queue_obj))
 {
 printf("QUEUE IS FULL\n");
 }
 else
 {
 printf("Enter Value=");
 scanf("%d",&value);
 INSERT(&queue_obj,value);
 }
 break;
 case 2:
 if(ISEMPTY(&queue_obj))
 {
 printf("QUEUE IS EMPTY\n");
 }
 else
 {
 DELETE(&queue_obj); 
 }
 break;
 case 3:DISPLAY(&queue_obj);
 break;
 case 4:
 if(ISFULL(&queue_obj))
 {
 printf("Queue is Full\n"); 
 }
 else
 {
 printf("Queue is not full yet\n");
 }
 break;
 case 5:
 if(ISEMPTY(&queue_obj))
 {
 printf("Queue is Empty\n");
 }
 else
 {
 printf("Queue is not empty yet\n");
 }
 break;
 default:printf("Inavlid Choice\n");
 }
 } while(choice!=0);
}