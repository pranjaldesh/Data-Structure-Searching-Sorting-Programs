#include<stdio.h>
void display(int array[],int n)
{
    int i;
    printf("[");
    for(i=0;i<n;i++)
    {
        printf("%d->",array[i]);
    }
    printf("]\n");
}
void quick_sort(int array[],int L,int H)
{
int pivot,temp,low,high;
pivot=array[L];
low=L+1;
high=H;
while(low<=high)
{
  while(low<=high && array[low]<pivot)
  {
      low++;
  }
  while(array[high]>pivot)
  {
      high--;
  }
  if(low<=high)
  {
      temp=array[low];
      array[low]=array[high];
      array[high]=temp;
      low++;
      high--;
  }
}
temp=array[L];
array[L]=array[high];
array[high]=temp;
if(L<high)
{
    quick_sort(array,L,high-1);
}
if(low<H)
{
    quick_sort(array,low,H);
}
}
void main()
{
    int n,i;
    printf("Please enter no.of ele:-");
    scanf("%d",&n);
    int array[n];
    printf("Please enter ele:-");
    for(i=0;i<n;i++)
    {
        scanf("%d",&array[i]);
    }
    printf("Unsorted Array:-");
    display(array,n);
    quick_sort(array,0,n-1);
    printf("Sorted Array:-");
    display(array,n);
}