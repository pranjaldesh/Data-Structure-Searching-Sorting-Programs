#include<stdio.h>
#include<stdlib.h>
struct stack
{
    int data;
    struct stack* next;
};
struct stack* createnode()
{
    int x;
    struct stack* newnode=NULL;
    newnode=(struct stack*)malloc(sizeof(struct stack));
    if(newnode==NULL)
    {
        printf("Stack is empty\n");
        return NULL;
    }
    else
    {
        printf("Please enter a data:-\n");
        scanf("%d",&x);
        newnode->data=x;
        newnode->next=NULL;
        return newnode;
    }
}
void PUSH(struct stack** top)
{
    struct stack* newnode=NULL;
    newnode=createnode();
    if(*top==NULL)
    {
        *top=newnode;
    }
    else
    {
        newnode->next=*top;
        *top=newnode;
    }
}
void POP(struct stack** top)
{
    if(*top==NULL)
    {
        printf("Stack is empty\n");
    }
    else
    {
        struct stack* tempnode=*top;
        printf("%d is popped element",(*top)->data);
        *top=(*top)->next;
        free(tempnode);
    }
}
void DISPLAY(struct stack* top)
{
    while(top!=NULL)
    {
        printf("%d->",top->data);
        top=top->next;
    }
}
void ISUNDERFLOW(struct stack* top)
{
    if(top==NULL)
    {
        printf("Stack is empty\n");
    }
}
void main()
{
    struct stack* top=NULL;
    int choice,value;
    do
    {
        printf("\n1.PUSH\n");
        printf("2.POP\n");
        printf("3.ISUNDERFLOW\n");
        printf("4.DISPLAY\n");
        printf("Please enter ur choice:-\n");
        scanf("%d",&choice);
        switch(choice)
        {
        case 1:PUSH(&top);
        break;
        case 2:POP(&top);
        break;
        case 3:ISUNDERFLOW(top);
        break;
        case 4:DISPLAY(top);
        break;
        default:printf("Invalid Choice");
        }
    } while(choice);
}