#include<stdio.h>
void display(int array[],int n)
{
    int i;
    printf("[");
    for(i=0;i<n;i++)
    {
        printf("%d, ",array[i]);
    }
    printf("]\n");
}
void Bubble_Sort(int array[],int n)
{
    int trav,i,temp,flag=0;
    for(trav=1;trav<n;trav++)
    {
        for(i=0;i<n-trav;i++)
        {
            if(array[i]>array[i+1])
            {
                flag=1;
                temp=array[i];
                array[i]=array[i+1];
                array[i+1]=temp;
            }
        }
    }
    if(flag==0)
    {
        printf("Array is already sorted\n");
    }
}
void main()
{
    int n,i;
    printf("Please enter no.of ele u wnt to insert:-");
    scanf("%d",&n);
    int array[n];
    printf("Please enter array element:-");
    for(i=0;i<n;i++)
    {
        scanf("%d",&array[i]);
    }
    printf("Unsorted array elements are:-\n");
    display(array,n);
    Bubble_Sort(array,n);
    printf("Sorted array elements are:-\n");
    display(array,n);
}




































































